<?php
function fpb($a,$b){
	while ($b != 0){
		$c=$a % $b;
		$a=$b;
		$b=$c;
	}
	return $a;
}

function kpk($a,$b){
	$hasil=($a*$b)/fpb($a,$b);
	return $hasil;
}

echo "FPB nya ". fpb(8,16)."</br>";
echo "KPK nya ". kpk(8,16);
?>