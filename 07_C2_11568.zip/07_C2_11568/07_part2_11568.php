<?php
function maks($a,$b){
	if ($a>$b){
		$maks= $a;
	}
	else{
		$maks=$b;}
	return $maks;
}

echo maks(4,8);
?>