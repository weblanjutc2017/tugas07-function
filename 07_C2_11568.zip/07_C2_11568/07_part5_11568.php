<?php
function fibonacci($a){
	$x=0;
	$y=1;
	echo $x." ".$y;
	
	for($i=0;$i<$a-2;$i++){
		$hasil=$x+$y;
		$x=$y;
		$y=$hasil;
		echo " ".$hasil;
	}
}
fibonacci(40);
?>