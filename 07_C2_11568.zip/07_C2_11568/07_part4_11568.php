<?php
function ganjil($a){
	$n=0;
	echo "deret bilangan ganjil: ";
	for($x=1;$x<=$a;$x++){
		if($x%2!=0){
			echo $x;
			echo " ";
			$n=$n+$x;
		}
	}
	echo "</br>";
	echo "jumlah = " . $n;
}
ganjil(10);

echo "</br>";
echo "</br>";
function genap($a){
	$j=0;
	echo "deret bilangan genap: ";
	for($i=1;$i<=$a; $i++){
		if($i%2==0){
			echo $i;
			echo " ";
			$j=$j+$i;
		}
	}
	echo "</br>";
	echo "jumlah = " . $j;
}

genap(10);
?>
