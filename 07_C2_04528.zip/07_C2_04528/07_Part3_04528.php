<?php


function hitungfpb($angka1 , $angka2){
	while($angka2 != 0){
		$c = $angka1 % $angka2;
		$angka1 = $angka2;
		$angka2 = $c;
		return $angka1;
	}
}

function hitungkpk($angka1 , $angka2){
	$c=$angka1;
	while($c % $angka2 != 0){
		$c = $c + $angka1;
		return $c;
	}
}


echo "FPB dari 60 dan 3 adalah : ".hitungfpb(60,3)."<br/>";
echo "KPK dari 45 dan 15 adalah : ".hitungkpk(45,19)."<br/>";
?>