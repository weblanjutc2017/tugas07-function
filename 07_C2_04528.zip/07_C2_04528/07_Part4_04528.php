<?php
	
for ($angkaganjil = 1; $angkaganjil <= 100; $angkaganjil++) {
	if ($angkaganjil % 2 == 1) {
		echo "$angkaganjil + " ;
	}
}
for ($angkagenap = 2; $angkagenap <= 100; $angkagenap++) {
	if ($angkagenap % 4 == 2) {
		echo "$angkagenap + " ;
	}
}


?>
