<?php
function name($fname)
	{
		echo "$fname<br/>";
	}
echo "Berikut ini nama mahasiswa yang mempunyai nama depan Ahmad: <br/>";
echo name("Ahmad Zakaria");
echo name("Ahmad Latif");
echo name("Ahmad Fadillah");
?>