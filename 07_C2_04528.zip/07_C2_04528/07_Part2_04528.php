<?php

	function hitungMaksimal($angka1,$angka2){
		if($angka1 < $angka2){
			 return $hasil=$angka2;
		}elseif($angka1 > $angka2){
			 return $hasil=$angka1;
		}else{
			 return $hasil="angka bernilai sama";
		}
	}
	
	echo "angka 7 dan 8 yang terbesar adalah: ".hitungMaksimal(7,8)."<br/>";
	echo "angka 12 dan 6 yang terbesar adalah: ".hitungMaksimal(12,6)."<br/>";
	echo "angka 9 dan 9 yang terbesar adalah: ".hitungMaksimal(9,9)."<br/>";
?>