<?php
function genap($a){
	echo "Deret Bilangan Genap Kurang Dari ";
	$c = 0;
	for($i=1; $i <= $a; $i++){
		if($i % 2==0){
			echo " $i ";
			$c = $c + $i;
		}
	}
	echo "<br/>";
	echo "Jumlah genap: " . $c;
}
Genap(100);
echo "<br/>";

function ganjil($b){
	echo "Deret Bilangan Ganjil Kurang Dari";
	$c = 0;
	for($j=1; $j <= $b; $j++){
		if($j % 2!=0){
			echo " $j ";
			$c = $c + $j;
		}
		
	}
	echo "<br/>";
	echo "Jumlah genap: " . $c;
}
Ganjil(100);

?>