<?php
function banding($a, $b)
{

 if ($a > $b) { 
  echo $a;
 } 
 else{
 echo $b;
 }

}
banding(25, 10);
?>