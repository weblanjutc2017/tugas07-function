<?php
function fibonacci($w){
	echo "Urutan bilangan ke-$w : 1 ";
	$x = 0; $y = 1; $z;
	for($i = 1; $i < $w-1; $i++){
		$z = $y;
		$z = $x;
		$x = $y;
		$y = $z + $y;
		
		echo $y . " ";
	}
}
fibonacci(40);
?>