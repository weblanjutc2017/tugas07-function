<?php
function fpb($a, $b){
	while ($b!=0){
	$c = $a % $b;
	$a = $b;
	$b = $c;
	}
	return $a;
}

function kpk($a, $b){
	$c = $a;
	while($c % $b !=0){
		$c = $c + $a;
	}
	return $c;
}

echo "FPB: " .fpb(24,32) . "<br/>";
echo "KPK: " . kpk(12,18);
?>