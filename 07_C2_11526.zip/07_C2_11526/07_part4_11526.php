<?php
function deret($a){
	echo "<b>Menampilkan deret dan jumlah deret bilangan ganjil dan bilangan genap yang kurang dari $a</b></br>";
	//ganjil;
	$n=1;
	$jumgan=0;
	while ($n<$a) {
		echo "$n";
		if($n!=$a-1){
			echo "+";
		}
		$jumgan=$jumgan+$n;
		$n=$n+2;
	}
	echo "</br>Jumlah = $jumgan</br>";
	//genap
	$x=2;
	$jumgen=0;
	while ($x<$a) {
		echo "$x";
		if($x!=$a-2){
			echo "+";
		}
		$jumgen=$jumgen+$x;
		$x=$x+2;
	}
	echo "</br>Jumlah = $jumgen</br>";

}

deret(10);
deret(100);
?>