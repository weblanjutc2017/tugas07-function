<?php
function maks($a,$b){
	echo "<b>nilainya adalah $a dan $b</b></br>";
	if ($a>$b) {
		echo "nilai terbesar adalah : $a</br>";
	} elseif ($b>$a) {
		echo "nilai terbesar adalah : $b</br>";	}
		else{
			echo "nilainya sama</br>";
		}
}

maks(11,11);
maks(11,121);
?>