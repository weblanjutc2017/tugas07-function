<?php
function fibonachi($a){
	$x=0;
	$y=1;
	$z;
	$p=1;
	while ($p<$a-1) {
		$z=$y;
		$z=$x;
		$x=$y;
		$y=$z+$y;
		$p++;
	}
	
	echo "Urutan ke-$a : $y</br>";
}
fibonachi(6);
fibonachi(40);
?>