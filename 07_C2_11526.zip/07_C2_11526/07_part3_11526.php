<?php
function carifpbkpk($a,$b){
	echo "Hasil dari $a dan $b adalah </br>";
	$x=$a;
	$y=$b;
	while ($b!=0) {
		$c=$a%$b;
		$a=$b;
		$b=$c;
	}

	echo "FPB : $a </br>";
	$p=$x;
	while ($p%$y!=0) {
		$p=$p+$x;
	}
	echo "KPK : $p</br>";
}

carifpbkpk(4,6);
carifpbkpk(5,21);
?>