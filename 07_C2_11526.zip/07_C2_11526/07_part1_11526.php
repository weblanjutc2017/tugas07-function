<?php
	function name($lname,$fname = "Ahmad")
	{
	 echo "$fname $lname <br/>";
	}
	echo "Berikut ini nama mahasiswa yang mempunyai nama depan Ahmad: <br/>";
	echo name("Zakaria");
	echo name("Latif");
	echo name("Fadillah");
?>