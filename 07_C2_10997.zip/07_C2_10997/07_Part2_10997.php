<?php
	function maxi($a, $b){
		echo "Nilai max dari $a dan $b adalah ";
		$nilai;
		if($a > $b){
			$nilai = $a;
		}
		else{
			$nilai = $b;
		}
		return $nilai;
	}
	
	echo maxi(19,32);
?>