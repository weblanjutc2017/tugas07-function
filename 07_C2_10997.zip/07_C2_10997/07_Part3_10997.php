<?php
	function fpb($a, $b){
		echo "FPB dari $a dan $b adalah :  ";
		while ($b != 0){
			$c = $a % $b;
			$a = $b;
			$b = $c;
		}
		echo $a . "<br>";
	}
	
	function kpk($a, $b){
		echo "KPK dari $a dan $b adalah :  ";
		$c = $a;
		while ($c % $b != 0){
			$c = $c + $a;
		}
		echo $c;
	}
	
	fpb(30,5);
	kpk(30,5);
?>