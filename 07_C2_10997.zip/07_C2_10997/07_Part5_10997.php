<?php
function fibonacci($urutan)
{
	if($urutan == 1 || $urutan == 2){
		$output = $urutan-1;
	}
	else{
		$x=0;
		$y=1;
  
		for ($i=0; $i<$urutan-2; $i++){
			$output = $y + $x;
			$x = $y;
			$y = $output;
		}
	}
	return "ke-$urutan adalah " . $output . "<br>";
}

echo "Pada bilangan fibonaci urutan angka : <br>";
echo fibonacci(1);
echo fibonacci(2);
echo fibonacci(3);
echo fibonacci(4);
echo fibonacci(5);
echo fibonacci(20);

?>