<?php
	function deretGanjil(){
		$x = 1;
		echo $x;
		for($x=2; $x<=100 ;$x++){
			if($x % 2 != 0){
				echo "+$x";
			}	
		}
	}
	
	function ganjil(){
		$jumlah = 0;
		for($x=1; $x<=100 ;$x++){
			if($x % 2 != 0){
				$jumlah = $jumlah + $x;
			}	
		}
		return $jumlah;
	}
	
	function deretGenap(){
		$x = 2;
		echo $x;
		for($x=3; $x<=100 ;$x++){
			if($x % 2 == 0){
				echo "+$x";
			}	
		}
	}
	
	function genap(){
		$jumlah = 0;
		for($x=1; $x<=100 ;$x++){
			if($x % 2 == 0){
				$jumlah = $jumlah+$x;
			}	
		}
		return $jumlah;
	}
	
	echo "Deret bilangan Ganjil kurang dari 100 : <br> ";
	deretGanjil();
	echo "<br> Jumlah = ".ganjil();
	
	echo "<br>";
	
	echo "Deret bilangan Genap kurang dari 100 : <br> ";
	deretGenap();
	echo "<br> Jumlah = ".genap();
?>