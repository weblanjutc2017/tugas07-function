<?php

function Ganjil($b){
	echo "Deret bilangan ganjil : ";
	$c=0;
	for($j=1; $j<$b; $j++){
		if($j%2!=0){
			echo $j;
			echo " ";
			$c=$c+$j;
		}
		
	}
	echo "<br/>";
	echo "Jumlah : " . $c;
}
Ganjil(100);
echo "<br/>";
echo "<br/>";
echo "<br/>";

function Genap($a){
	echo "Deret bilangan genap : ";
	$c=0;
	for($i=1; $i <$a; $i++){
		if($i%2==0){
			echo $i;
			echo " ";
			$c=$c+$i;
		}
	}
	echo "<br/>";
	echo "Jumlah : " . $c;
}
Genap(100);
?>