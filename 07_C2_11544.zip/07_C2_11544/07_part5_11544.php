<?php
function Fibonacci($a){
	echo "urutan bilangan ke-$a : 1 ";
	$b=0; $c=1; $d;
	for($i=1; $i<$a-1; $i++){
		$d=$c;
		$d=$b;
		$b=$c;
		$c=$d+$c;
		
		echo $c . " ";
	}
	
	
}

Fibonacci(40);

?>