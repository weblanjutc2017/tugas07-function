<?php
function maks($a, $b){
	if($a>$b){
		return $a;
	}
	else{
		return $b;
	}
}

echo "Nilai maks: " . maks(2, 5);
?>